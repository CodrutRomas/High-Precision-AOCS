# AOCS Simulator 
 
High-Precision Attitude and Orbit Control System Simulator 
for 6U CubeSats with real-time 3D visualization. 
 
USAGE: 
  1. Double-click AOCS_Simulator.exe to start 
  2. Select mission mode from dropdown 
  3. Click Start to begin simulation 
  4. Press ESC to exit fullscreen 
 
CONTROLS: 
  - Mouse wheel: Zoom in 3D view 
  - Dropdown: Change mission modes 
  - Speed buttons: Adjust simulation time 
 
MISSION MODES: 
  - Detumbling: Initial stabilization 
  - Sun Acquisition: Solar panel alignment 
  - Ground Contact: Earth nadir pointing 
  - Emergency Safe: Fault-tolerant mode 
 
For technical details, visit: 
https://github.com/[YOUR_USERNAME]/High-precision-AOCS 
